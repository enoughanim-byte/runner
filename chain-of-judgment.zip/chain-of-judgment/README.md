# ⛓️ Chain of Judgment — Multiplayer Anatomy Quiz Runner

> Two chained souls run from Hell to Heaven — answer anatomy questions or face JUDGMENT.

## 🎮 Gameplay

1. **Player 1** creates a room → gets a 6-character code
2. **Player 2** enters the code → both are connected by a magical chain
3. Every ~20 seconds a **Anatomy question** appears with two door options
4. Both players tap **LEFT** (Door A) or **RIGHT** (Door B) to vote
5. **Both agree + correct** → ascend, score, combo!
6. **Wrong answer** → dramatic death animation, respawn, try again

## ⛓️ Chain Mechanic
- Players are permanently connected — if you stretch the chain too far, tension builds
- **Split vote** (each chooses different door) = **immediate CHAIN JUDGMENT** punishment
- Coordinate your answers!

## 💀 Death Animations
| Type | Description |
|------|-------------|
| 🔥 Lava Rise | Lava floods up from below, drowning both souls |
| 👹 Demon Devour | Giant demon eyes & mouth close in from the darkness |
| ⚙️ Blade Execution | Two sawblades spin in from both sides |
| 💀 Crush | Spiked walls close in from left and right |
| ⚡ Chain Judgment | Lightning judgment for split votes |

## 📚 Question Bank: 80 Questions
- 🦴 **Bones** (25) — skull, spine, limbs
- 💪 **Muscles** (12) — major muscle groups
- 🫀 **Organs** (18) — heart, liver, kidneys, lungs
- 🩺 **Physiology** (12) — vital signs, blood, function
- 📖 **Medical Terms** (13) — prefixes & what they mean

---

## 🚀 Deploy to Railway

### Step 1 — GitHub Repo
```bash
# Create new repo at github.com/new named "chain-of-judgment"
git clone https://github.com/YOUR_USERNAME/chain-of-judgment
cd chain-of-judgment
# Copy all files here
git add .
git commit -m "Chain of Judgment v1"
git push
```

### Step 2 — Railway Deploy
1. Go to [railway.app](https://railway.app) → Login with GitHub
2. New Project → Deploy from GitHub → select `chain-of-judgment`
3. Railway auto-detects Node.js → click Deploy
4. Settings → Networking → Generate Domain

### Step 3 — Play!
Share the Railway URL with a friend → both open it → create/join room → play!

---

## 💻 Run Locally
```bash
npm install
npm start
# Open http://localhost:3000 in two browser tabs
```

## 🎨 What's Next (Full Game Roadmap)
- [ ] Zone progression: Hell → Purgatory → Sky Realm → Heaven
- [ ] Stylized 3D characters (Three.js or Babylon.js)
- [ ] More death sequences (serpent, lightning chamber, fire pit)
- [ ] Moving platforms and obstacles
- [ ] Combo streak rewards
- [ ] Leaderboard & persistent scores
- [ ] Lobby with up to 4 players per room
- [ ] Sound effects & music (hell ambience → heavenly choir)
- [ ] Mobile app wrapper (Capacitor → real APK)
